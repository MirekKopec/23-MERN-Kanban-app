export default {
  NOTE: 'note',
};