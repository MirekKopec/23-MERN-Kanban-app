import Kanban from '../models/kanban';

export function getSomething(req, res) {
  return res.status(200).end();
}
