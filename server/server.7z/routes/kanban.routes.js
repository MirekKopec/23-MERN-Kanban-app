import { Router } from 'express';
import * as KanbanController from '../controllers/kanban.controller';

const router = new Router();


export default router;
